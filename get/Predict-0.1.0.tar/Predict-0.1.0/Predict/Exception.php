<?php

class Predict_Exception extends Exception
{
}
