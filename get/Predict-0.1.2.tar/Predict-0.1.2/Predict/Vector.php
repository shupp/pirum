<?php

/**
 * Predict_Vector - General three-dimensional vector structure.
 * Ported from sgp4sdp4.h.
 */
class Predict_Vector
{
    public $x = 0;
    public $y = 0;
    public $z = 0;
    public $w = 0;
}
