<?php

class Services_IPPower_Exception extends Exception
{
}
